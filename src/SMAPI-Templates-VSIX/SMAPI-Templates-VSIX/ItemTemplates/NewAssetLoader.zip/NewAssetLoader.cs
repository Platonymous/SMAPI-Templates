﻿using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using xTile;

namespace $rootnamespace$
{
    class $safeitemname$ : IAssetLoader
    {
        // Add to Entry: helper.Content.AssetLoaders.Add(new $rootnamespace$.$safeitemname$(helper));

        private IModHelper helper;

        public $safeitemname$(IModHelper helper)
        {
            this.helper = helper;
        }

        public bool CanLoad<T>(IAssetInfo asset)
        {
            return asset.AssetNameEquals(@"Texture/To/Replace") || asset.AssetNameEquals(@"Map/To/Replace");
        }

        public T Load<T>(IAssetInfo asset)
        {
            if (asset.AssetNameEquals(@"Texture/To/Replace"))
                return (T)(object)helper.Content.Load<Texture2D>(@"MyAssets/ReplacementTexture.png", ContentSource.ModFolder);
            else if (asset.AssetNameEquals(@"Map/To/Replace"))
                return (T)(object)helper.Content.Load<Map>(@"MyAssets/ReplacementMap.tbin", ContentSource.ModFolder);

            return (T)(object)null;
        }
    }
}
