﻿using Microsoft.Xna.Framework;

namespace $safeprojectname$
{
    class Config
    {
        public int messageType { get; set; }

        public Config()
        {
            messageType = 1;
        }
    }
}
