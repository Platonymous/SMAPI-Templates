﻿using Microsoft.Xna.Framework.Input;

namespace $safeprojectname$
{
    class Config
    {
        public Keys debugKey { get; set; }

        public Config()
        {
            debugKey = Keys.J;
        }
    }
}
