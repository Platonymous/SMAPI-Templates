﻿using StardewModdingAPI;

namespace $safeprojectname$
{
    class Config
    {
        public SButton debugKey { get; set; }

        public Config()
        {
            debugKey = SButton.J;
        }
    }
}
