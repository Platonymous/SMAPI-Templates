﻿using System.Collections.Generic;

namespace CustomitemTemplate
{
    public class Items
    {
        public List<Data> Content { get; set; }
    }
}
